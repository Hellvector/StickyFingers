This is an addon by NewbieC4 to track money made by using Pick Pocket.
